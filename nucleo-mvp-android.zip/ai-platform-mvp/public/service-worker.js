// service-worker.js — mínimo necessário para o navegador considerar o
// Núcleo instalável como app (PWA). Não faz cache agressivo de propósito:
// como a IA e os dados rodam localmente (Ollama + JSON), preferimos sempre
// buscar a versão mais nova em vez de servir algo desatualizado do cache.

const CACHE_NAME = 'nucleo-shell-v1';
const SHELL_FILES = ['/', '/manifest.json'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_FILES))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Network-first: tenta a rede (localhost:3000 sempre atualizado);
// só usa o cache como fallback se o servidor estiver fora do ar.
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    fetch(event.request)
      .then((res) => {
        const resClone = res.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, resClone));
        return res;
      })
      .catch(() => caches.match(event.request))
  );
});
