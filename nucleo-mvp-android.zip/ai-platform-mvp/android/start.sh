#!/data/data/com.termux/files/usr/bin/bash
# start.sh — inicia o Ollama e o servidor do Núcleo dentro do Termux.
# Rode de dentro da pasta do projeto:
#   bash android/start.sh
#
# Deixe o Termux aberto (ou minimizado) enquanto usa o app.
# Feche com Ctrl+C.

# Modelo leve por padrão — troque aqui se quiser usar outro (ex.: gemma3:4b)
export OLLAMA_MODEL="${OLLAMA_MODEL:-llama3.2:1b}"

# Evita que o Android suspenda o processo em segundo plano
termux-wake-lock 2>/dev/null || echo "(dica: instale o pacote 'termux-api' para habilitar wake-lock)"

# Sobe o Ollama se ainda não estiver rodando
if ! pgrep -x ollama >/dev/null; then
  echo "Iniciando Ollama..."
  nohup ollama serve > "$PREFIX/var/log/ollama.log" 2>&1 &
  sleep 3
fi

echo "Modelo de IA: $OLLAMA_MODEL"
echo "Abra o navegador do celular em: http://localhost:3000"
echo ""

node server.js

# Ao encerrar o servidor, libera o wake-lock
termux-wake-unlock 2>/dev/null
