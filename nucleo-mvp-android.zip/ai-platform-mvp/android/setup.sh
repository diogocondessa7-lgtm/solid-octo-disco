#!/data/data/com.termux/files/usr/bin/bash
# setup.sh — instala tudo que o Núcleo precisa dentro do Termux (Android).
# Rode este script UMA VEZ, de dentro da pasta do projeto:
#   bash android/setup.sh

set -e

echo "== 1/5: Atualizando pacotes do Termux =="
pkg update -y && pkg upgrade -y

echo "== 2/5: Instalando Node.js =="
pkg install -y nodejs

echo "== 3/5: Instalando Ollama (IA local) =="
pkg install -y ollama

echo "== 4/5: Instalando dependências do projeto (npm install) =="
npm install

echo "== 5/5: Baixando um modelo leve, adequado para celular =="
# llama3.2:1b (~1.3GB) roda bem na maioria dos aparelhos com 4GB+ de RAM.
# Se seu celular tiver 8GB+ de RAM, pode trocar por um modelo maior depois
# (ex.: ollama pull gemma3:4b) e ajustar OLLAMA_MODEL no android/start.sh.
nohup ollama serve > "$PREFIX/var/log/ollama.log" 2>&1 &
sleep 3
ollama pull llama3.2:1b

echo ""
echo "Tudo pronto! Para iniciar o Núcleo, rode:"
echo "  bash android/start.sh"
