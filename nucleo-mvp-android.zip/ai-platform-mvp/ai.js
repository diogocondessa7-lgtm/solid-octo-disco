// ai.js — camada de IA 100% gratuita e open source.
//
// Modelo de linguagem: Ollama (https://ollama.com), rodando LOCALMENTE.
// Ollama é gratuito, open source, e roda modelos abertos como Llama 3,
// Mistral, Gemma, DeepSeek etc. sem precisar de chave de API paga.
//
// Busca web: DuckDuckGo Instant Answer API (gratuita, sem chave, sem cadastro).

const OLLAMA_URL = process.env.OLLAMA_URL || 'http://localhost:11434/api/generate';
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || 'llama3';

async function askLocalAI(prompt) {
  try {
    const res = await fetch(OLLAMA_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: OLLAMA_MODEL, prompt, stream: false }),
    });
    if (!res.ok) throw new Error(`Ollama respondeu ${res.status}`);
    const data = await res.json();
    return data.response;
  } catch (err) {
    return (
      '[IA local não disponível] Instale o Ollama (https://ollama.com) e rode ' +
      `"ollama pull ${OLLAMA_MODEL}" para ativar respostas de IA. ` +
      `Detalhe técnico: ${err.message}`
    );
  }
}

async function searchWeb(query) {
  try {
    const url = `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`;
    const res = await fetch(url);
    const data = await res.json();
    const results = [];
    if (data.AbstractText) {
      results.push({ title: data.Heading || query, text: data.AbstractText, url: data.AbstractURL });
    }
    if (Array.isArray(data.RelatedTopics)) {
      for (const topic of data.RelatedTopics.slice(0, 5)) {
        if (topic.Text) results.push({ title: topic.Text.slice(0, 60), text: topic.Text, url: topic.FirstURL });
      }
    }
    return results;
  } catch (err) {
    return [];
  }
}

module.exports = { askLocalAI, searchWeb, OLLAMA_MODEL };
