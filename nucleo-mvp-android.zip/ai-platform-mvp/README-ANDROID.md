# Núcleo no Android (via Termux)

Esta é a versão "tudo no celular": o servidor Node.js **e** a IA (Ollama) rodam
localmente no seu Android, sem precisar de PC, servidor externo ou chave de
API paga. Continua 100% gratuito e offline (depois da instalação inicial).

⚠️ Requisitos de hardware: recomendado **4GB+ de RAM** para o modelo leve
padrão. Celulares com 2-3GB de RAM podem funcionar, mas com lentidão.

## 1. Instalar o Termux

Use a versão do **F-Droid** ou do **GitHub Releases** do Termux — a versão da
Google Play Store está desatualizada e não funciona bem para isso.

- F-Droid: https://f-droid.org/packages/com.termux/
- GitHub: https://github.com/termux/termux-app/releases

## 2. Colocar o projeto no celular

Dentro do Termux:

```bash
pkg install -y git
git clone <URL_DO_SEU_REPOSITORIO_NO_GITHUB> nucleo
cd nucleo
```

(Ou copie a pasta do projeto para dentro do Termux por outro meio, se preferir.)

## 3. Rodar o instalador

```bash
bash android/setup.sh
```

Isso vai, em ordem:
1. Atualizar os pacotes do Termux
2. Instalar Node.js
3. Instalar o Ollama (disponível oficialmente no repositório do Termux, sem precisar de root)
4. Instalar as dependências do projeto (`npm install`)
5. Baixar um modelo de IA leve (`llama3.2:1b`, ~1.3GB) adequado para celular

A instalação inicial baixa alguns GB de dados — prefira usar Wi-Fi.

## 4. Iniciar o Núcleo

```bash
bash android/start.sh
```

Deixe o Termux aberto (pode minimizar) e acesse, no navegador do próprio
celular:

```
http://localhost:3000
```

O primeiro cadastro que você fizer vira automaticamente admin, como na
versão de PC.

## Trocar o modelo de IA

O padrão (`llama3.2:1b`) prioriza rodar bem em mais aparelhos. Se seu celular
tiver 8GB+ de RAM, você pode usar um modelo mais capaz:

```bash
ollama pull gemma3:4b
OLLAMA_MODEL=gemma3:4b bash android/start.sh
```

## Problemas comuns

- **"Ollama respondeu" erro / IA não responde**: confirme que o Ollama está
  rodando (`pgrep ollama`) e que o modelo foi baixado (`ollama list`).
- **App para de responder com a tela bloqueada**: o Android 12+ tem um
  "Phantom Process Killer" que mata processos em segundo plano. O
  `android/start.sh` já ativa `termux-wake-lock` para reduzir isso — instale
  o pacote `termux-api` (`pkg install termux-api`) e o app **Termux:API** para
  habilitar esse recurso, e desative a otimização de bateria do Termux nas
  configurações do Android.
- **Erro de espaço em disco**: modelos de IA ocupam espaço — confira em
  `Configurações > Armazenamento` antes de baixar modelos maiores.
- **Quero que inicie sozinho ao ligar o Termux**: instale o app
  **Termux:Boot** e mova um script equivalente ao `android/start.sh` para
  `~/.termux/boot/`.

## Transformar em app (ícone na tela inicial)

Com o servidor rodando (`bash android/start.sh`), abra `http://localhost:3000`
no navegador do celular (Chrome ou Brave) e:

1. Toque no menu do navegador (⋮)
2. Toque em **"Adicionar à tela inicial"** / **"Instalar app"**
3. Confirme

Isso cria um ícone próprio do Núcleo na tela inicial. Ao abrir por ele, o app
roda em tela cheia, sem a barra de endereço do navegador — como um app
normal. Por baixo dos panos ele continua sendo o mesmo servidor local, então
o Termux com `android/start.sh` rodando precisa continuar ativo em segundo
plano para o app funcionar.

Isso é possível porque o projeto já inclui um **manifesto PWA**
(`public/manifest.json`) e um **service worker** (`public/service-worker.js`),
que são os dois arquivos que o navegador exige para oferecer a instalação.

## O que muda em relação à versão de PC

Nada no código — `server.js`, `ai.js` e `db.js` são exatamente os mesmos.
A única diferença é o modelo de IA padrão (mais leve, pensado para celular)
e os scripts em `android/` que automatizam a instalação no Termux.
