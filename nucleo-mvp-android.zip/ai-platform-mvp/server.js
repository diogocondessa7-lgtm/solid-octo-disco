// server.js — núcleo da plataforma.
// Stack 100% gratuita e open source: Express + Multer + pdf-parse + JWT.

const express = require('express');
const multer = require('multer');
const pdfParse = require('pdf-parse');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const path = require('path');
const { loadDB, saveDB } = require('./db');
const { askLocalAI, searchWeb, OLLAMA_MODEL } = require('./ai');

const JWT_SECRET = process.env.JWT_SECRET || 'troque-este-segredo-em-producao';
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 15 * 1024 * 1024 } });

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ---------- Auth ----------
function authMiddleware(req, res, next) {
  const header = req.headers.authorization;
  if (!header) return res.status(401).json({ error: 'Não autenticado' });
  try {
    const token = header.replace('Bearer ', '');
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Token inválido' });
  }
}

app.post('/api/register', (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: 'Preencha nome, email e senha' });
  const db = loadDB();
  if (db.users.find((u) => u.email === email)) return res.status(400).json({ error: 'Email já cadastrado' });

  const isFirstUser = db.users.length === 0;
  const user = {
    id: Date.now().toString(),
    name,
    email,
    passwordHash: bcrypt.hashSync(password, 10),
    role: isFirstUser ? 'admin' : 'editor', // primeiro usuário vira admin automaticamente
    createdAt: new Date().toISOString(),
  };
  db.users.push(user);
  saveDB(db);
  res.json({ ok: true, role: user.role });
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  const db = loadDB();
  const user = db.users.find((u) => u.email === email);
  if (!user || !bcrypt.compareSync(password, user.passwordHash)) {
    return res.status(401).json({ error: 'Email ou senha inválidos' });
  }
  const token = jwt.sign({ id: user.id, name: user.name, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, name: user.name, role: user.role });
});

// ---------- Usuários (admin) ----------
app.get('/api/users', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Apenas admins' });
  const db = loadDB();
  res.json(db.users.map((u) => ({ id: u.id, name: u.name, email: u.email, role: u.role })));
});

// ---------- Objetos (projetos/agentes/bases de conhecimento) ----------
app.post('/api/objects', authMiddleware, (req, res) => {
  const { name, type, description } = req.body;
  const db = loadDB();
  const obj = {
    id: Date.now().toString(),
    name,
    type: type || 'projeto',
    description: description || '',
    ownerId: req.user.id,
    createdAt: new Date().toISOString(),
  };
  db.objects.push(obj);
  saveDB(db);
  res.json(obj);
});

app.get('/api/objects', authMiddleware, (req, res) => {
  const db = loadDB();
  res.json(db.objects.filter((o) => o.ownerId === req.user.id || req.user.role === 'admin'));
});

// ---------- Núcleo de IA: analisar texto/arquivo + buscar na web ----------
app.post('/api/analyze', authMiddleware, upload.single('file'), async (req, res) => {
  const question = req.body.question || 'Resuma e explique este conteúdo.';
  let extractedText = req.body.text || '';

  if (req.file) {
    if (req.file.mimetype === 'application/pdf') {
      const parsed = await pdfParse(req.file.buffer);
      extractedText = parsed.text;
    } else if (req.file.mimetype.startsWith('text/')) {
      extractedText = req.file.buffer.toString('utf-8');
    } else if (req.file.mimetype.startsWith('image/')) {
      extractedText = '[Arquivo de imagem recebido — análise visual requer um modelo multimodal, ex.: LLaVA via Ollama]';
    } else {
      extractedText = `[Arquivo "${req.file.originalname}" recebido, tipo ${req.file.mimetype} não indexado em texto]`;
    }
  }

  const webResults = await searchWeb(question);
  const webContext = webResults.map((r) => `- ${r.title}: ${r.text}`).join('\n');

  const prompt = `Você é um assistente que responde com base no conteúdo fornecido e em informações da web.

CONTEÚDO DO ARQUIVO/TEXTO:
${extractedText.slice(0, 4000) || '(nenhum conteúdo enviado)'}

INFORMAÇÕES DA WEB:
${webContext || '(nenhum resultado relevante)'}

PERGUNTA DO USUÁRIO: ${question}

Responda de forma clara e objetiva, citando quando a informação vem da web.`;

  const answer = await askLocalAI(prompt);

  const db = loadDB();
  const entry = {
    id: Date.now().toString(),
    userId: req.user.id,
    question,
    fileName: req.file?.originalname || null,
    answer,
    webResults,
    createdAt: new Date().toISOString(),
  };
  db.history.push(entry);
  saveDB(db);

  res.json(entry);
});

app.get('/api/history', authMiddleware, (req, res) => {
  const db = loadDB();
  res.json(db.history.filter((h) => h.userId === req.user.id).reverse());
});

app.get('/api/status', (req, res) => {
  res.json({ ok: true, model: OLLAMA_MODEL });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Plataforma rodando em http://localhost:${PORT}`));
